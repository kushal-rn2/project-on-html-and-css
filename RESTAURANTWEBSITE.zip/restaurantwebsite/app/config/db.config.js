module.exports = {
    HOST : "localhost",
    USER : "root",
    PASSWORD : "karthu@123",
    DB:"restaurant"
};